create database QLBongDa
go
use database QLBongDa
go